% Script functions:
% 1) Read in CSV files and extract time, x and y data, arrange in struct
% 2) Calculate root mean square (RMS) for each trace and computes the average of 3 simulation replicates
% 3) Fits a simple model to the RMS vs tether length data

%% Read in CVS files

% Specify which folder needs to be analyzed:
AnalyzeFolder=['C:\Example 1 data\RMS Data 1000 um Bead_case study'];

OldFolder=cd;
cd(AnalyzeFolder)
fileList = dir('*.csv');
cd(OldFolder);  % switch back to the current folder

% the loop below imports all the data in the CSV file, but only keeps time, x and y position. 
% Can be modified to import more data for other purposes

for i=1:length(fileList)
    A=Sub_import_csv(fileList(i).folder,fileList(i).name);
    Data(i).length=fileList(i).name;
    Data(i).time = A.Time;
    Data(i).x = A.XPosition;
    Data(i).y = A.YPosition; 
end
clear A

%% Extract the tether length from the text field and convert it to number

for i=1:length(Data)
    str=Data(i).length;
    match=["data", ".csv"];
    str = erase(str,match); % remove data and csv from string
    str=eraseBetween(str,"_",length(str),"Boundaries","inclusive");
    l=str2num(str);
    Data(i).LC=l;
end

%% Calculate RMS for each entry

for i=1:length(Data)
    x=Data(i).x;
    y=Data(i).y;
    xmean=mean(x);
    ymean=mean(y);
    RMS=sqrt(mean((x-xmean).^2+(y-ymean).^2));
    Data(i).RMS=RMS; %RMS unit is in meters
end

%% in a new data struct, combine the mean and standard deviation of the RMS data with tether length LC

LC=unique([Data.LC]); % get unique thether length values from struct
RMS_av=zeros(length(LC),1); %define averaged RMS vector and standard deviation
RMS_std=RMS_av;

for i=1:length(LC)
    idx=find([Data.LC]==LC(i)); % find indices in the Data.LC array which match the corresponding length
    RMS_av(i)=mean([Data(idx).RMS]);
    RMS_std(i)=std([Data(idx).RMS]);
end

% convert RMs from meter to nanometer

RMS_av=RMS_av*10^9;
RMS_std=RMS_std*10^9;

%% Plot RMS vs contour length with error bars

errorbar(LC,RMS_av,RMS_std,'o')
xlabel('Contour length (nm)')
ylabel('RMS (nm)')

%% Power fit to data and plot

% a power fit as y=a*x^b can be linearized as:
% ln(y)=b*ln(x)+ln(a), which can easily be fitted using linear regression
log_RMS=log(RMS_av);
log_LC=log(LC');
log_LC_fit=[ones(length(log_LC),1) log_LC]; % padding with ones so that we fit slope and intercept

beta=log_LC_fit\log_RMS; % curve fit; details see here: https://www.mathworks.com/help/matlab/data_analysis/linear-regression.html

% % optional: visualize linear fit
% RMS_calc=log_LC_fit*beta;
% figure, hold on
% plot(log_LC,log_RMS,'o'), 
% plot(log_LC,RMS_calc,'--')

% 'unlinearize intercept'
beta(1)=exp(beta(1));

% plot original data:
figure, hold on
errorbar(LC,RMS_av,RMS_std,'o')
LC_vec=linspace(0,max(LC),100);
plot(LC_vec,beta(1).*LC_vec.^beta(2),'-r')
xlabel('Contour length (nm)')
ylabel('RMS (nm)')
