% Script functions:
% 1) Read in CSV files and extract x, y, z and force data, arrange in struct
% 2) Plot extension versus force
% 3) Fit Marko-Siggia model to both data sets and plot fit

%% Read in CVS files

% Specify which folder needs to be analyzed:
AnalyzeFolder=['C:\Example 2 data and results'];

OldFolder=cd;
cd(AnalyzeFolder)
fileList = dir('*.csv');
cd(OldFolder);  % switch back to the current folder

% the loop below imports all the data in the CSV file, but only keeps x,y,z and force data. 
% Can be modified to import more data for other purposes

for i=1:length(fileList)
    A=Sub_import_csv(fileList(i).folder,fileList(i).name);
    Data(i).experiment=fileList(i).name;
    Data(i).x = A.XPosition; % in meters
    Data(i).y = A.YPosition; 
    Data(i).z = A.ZPosition;
    Data(i).F = A.AppliedForce; % in Newtons
end
clear A AnalyzeFolder OldFolder fileList;

%% Build tether length from x,y and z coordinates

for i=1:length(Data)
    x_temp=Data(i).x;
    y_temp=Data(i).y;
    z_temp=Data(i).z;
    distance_temp=sqrt(x_temp.^2+y_temp.^2+z_temp.^2);
    Data(i).distance=distance_temp;
end

clear x_temp y_temp z_temp distance_temp;

%% plot raw data for both persistence lengths

figure, hold on
for i=1:length(Data)
plot(Data(i).distance*10^9,Data(i).F*10^12,'o')
end

xlabel('Extension (nm)')
ylabel('Force (pN)')
legend('l_p = 45nm', 'l_p = 90nm', Location='northwest')

%% Fit Marko-Siggia (1995) WLC model

kBT=4.11; %pN*nm

% create anonymous function, Marko-Siggia WLC (1995)
F_mdl=@(lp,lo,x) (kBT./lp.*(1./(4.*(1-x./lo).^2)-1/4+x./lo));

for i=1:length(Data)
    x=Data(i).distance*10^9; % conversion to nm
    F=Data(i).F*10^12; % conversion to pN
    [output, gof]=fit(x,F,F_mdl,'StartPoint',[60,2000]); % fit model
    Data(i).lp=output.lp; % store fit parameters in struct
    Data(i).lo=output.lo;
    Data(i).gof=gof; % store goodness of fit in struct
end


%% plot data and fit

x_plot=linspace(0,max(x),100); % extension vector for estimation of force

figure

subplot(1,2,1), hold on % plot lp=45nm data
    plot(Data(1).distance*10^9,Data(1).F*10^12,'o')
    F_est=F_mdl(Data(1).lp,Data(1).lo,x_plot);
    plot(x_plot,F_est,'-')
    xlabel('Extension (nm)')
    ylabel('Force (pN)')
    legend('l_p = 45nm', 'fit', Location='northwest')
    ylim([0 35])
    xlim([0 2000])

subplot(1,2,2), hold on % plot lp=90nm data
    plot(Data(2).distance*10^9,Data(2).F*10^12,'o')
    F_est=F_mdl(Data(2).lp,Data(2).lo,x_plot);
    plot(x_plot,F_est,'-')
    xlabel('Extension (nm)')
    ylabel('Force (pN)')
    legend('l_p = 90nm', 'fit', Location='northwest')
    ylim([0 35])
    xlim([0 2000])