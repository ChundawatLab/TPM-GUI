function Out=Sub_import_csv(location,filename)
% Auto-generated using MATLAB and customized to consider file location

%% Input handling

% If dataLines is not specified, define defaults
% if nargin < 2
    dataLines = [2, Inf];
% end


%% Set up the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 11);

% Specify range and delimiter
opts.DataLines = dataLines;
opts.Delimiter = ",";

% Specify column names and types
opts.VariableNames = ["Time", "XPosition", "YPosition", "ZPosition", "Force", "AppliedForce", "XForce", "YForce", "ZForce", "Theta", "Phi"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Import the data
path=[location,'\',filename];
Out = readtable(path, opts);


%% Clear temporary variables
clear opts

end